package org.elsys.edu;

public class Subject 
{

	String name;
	boolean isSubjectMandatory;
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public boolean isMandatory() 
	{
		return isSubjectMandatory;
	}

	public void setMandatory(boolean mandatory) 
	{
		isSubjectMandatory = mandatory;
	}
	
}
