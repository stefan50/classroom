package org.elsys.edu;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

public class University extends AbstractEducationalInstitution 
{

	Integer tolerateFailedCourses;
	
	public University(Integer tolerate)
	{
		tolerateFailedCourses = tolerate;
	}
	
	@Override
	public boolean signUpForNextYear(Student student) 
	{
		if(student.getUncompletedSubjects().size() <= tolerateFailedCourses)
		{
			if(student.getCourse() == null)
			{
				student.setCourse(1);
			}
			else
			{
				student.setCourse(student.getCourse()+1);
			}
		}
		else
		{
			throw new EducationalInstitutionException();
		}
		return students.add(student);
	}
	
	@Override
	public List<Student> getStudentsInCourse(int course, boolean orderedByAverageGrade) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Integer, List<Student>> groupStudentsByGrade() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> order(Comparator<Student> comparator) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Student> filter(Predicate<Student> predicate) {
		// TODO Auto-generated method stub
		return null;
	}

}
