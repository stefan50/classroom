package org.elsys.edu;

public class EducationalInstitutionException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7308504034441100153L;

}
