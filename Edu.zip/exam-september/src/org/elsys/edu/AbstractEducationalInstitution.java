package org.elsys.edu;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

public abstract class AbstractEducationalInstitution implements EducationalInstitution 
{
	
	protected String name;
	protected Set<Student> students = new HashSet<>();
	
	@Override
	public String getName() 
	{
		return name;
	}

	@Override
	public boolean signUpForNextYear(Student student) 
	{
		return false;
	}

	@Override
	public boolean signOut(Student student) 
	{
		boolean isSignedOut = false;
		if(!students.contains(student))
		{
			isSignedOut = students.remove(student); 
		}
		return isSignedOut;
	}

	@Override
	public Collection<Student> getStudents() 
	{
		return students;
	}

	@Override
	public List<Student> getStudentsInCourse(int course, boolean orderedByAverageGrade) 
	{
		List<Student> studentsInCourse = new ArrayList<>();
		for(Student s: students)
		{
			if(s.getCourse().equals(course))
			{
				studentsInCourse.add(s);
			}
		}
		
		if(orderedByAverageGrade)
		{
			Collections.sort(studentsInCourse, (s1, s2) -> s1.getAverageGrade() - s2.getAverageGrade());
		}
		return studentsInCourse;
	}

	@Override
	public List<Student> order(Comparator<Student> comparator) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Student> filter(Predicate<Student> predicate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Integer, List<Student>> groupStudentsByGrade() {
		// TODO Auto-generated method stub
		return null;
	}

}
