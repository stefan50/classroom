package org.elsys.edu;

import java.util.Scanner;

public class MainClass 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		University myUni = new University(2);
		while(true)
		{
			String input = in.nextLine();
			if(input.equals("END"))
			{
				break;
			}
			String[] elements = input.split(", ");
			Student newStudent = new Student(elements[0], Integer.parseInt(elements[1]), Double.parseDouble(elements[2]));
			Subject s = new Subject();
			if(Integer.parseInt(elements[1]) % 2 == 0)
			{
				s.setName("Mandatory");
				s.setMandatory(true);
				
			}
			else if(Integer.parseInt(elements[1]) % 3 == 0)
			{
				s.setName("Not Mandatory");
				s.setMandatory(false);
			}
			newStudent.addUncompletedSubject(s);
			
			try
			{
				myUni.signUpForNextYear(newStudent);
			}
			catch(EducationalInstitutionException e)
			{
				System.out.println("Can't sign up for next year!");
			}
		}
		in.close();
	}
}
